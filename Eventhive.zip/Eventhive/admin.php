<?php
session_start();
if (!isset($_SESSION['username']) || $_SESSION['role'] !== 'admin') {
    header("Location: index.php");
    exit();
}
require_once "dbconnection.php";


$totalUsers = $pdo->query("SELECT COUNT(*) FROM users")->fetchColumn();
$totalEvents = $pdo->query("SELECT COUNT(*) FROM events")->fetchColumn();
$totalPurchases = $pdo->query("SELECT COUNT(*) FROM purchases")->fetchColumn();


$events = $pdo->query("SELECT *, image_url FROM events ORDER BY event_date DESC")->fetchAll();


$users = $pdo->query("SELECT id, username, email, role FROM users ORDER BY created_at DESC")->fetchAll();


$purchases = $pdo->query("
    SELECT p.*, u.username, e.title
    FROM purchases p
    JOIN users u ON p.user_id = u.id
    JOIN events e ON p.event_id = e.id
    ORDER BY p.purchase_date DESC
")->fetchAll();
?>
<!DOCTYPE html>
<html lang="pt-PT">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="description" content="Painel de administração da EventHive">
  <meta name="keywords" content="Gestão de eventos, bilhetes, concertos, espetáculos, festivais, artistas, bandas, música, cultura">
  <meta name="author" content="Pedro Costa">
  <title>Painel Admin</title>
  <link rel="stylesheet" href="./Styles/style.css">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/remixicon/fonts/remixicon.css">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.7/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<header class="header" id="header">
  <nav class="nav container">
    <a href="index.php" class="nav__logo"><img src="./Images/logo.png" alt="logo EventHive"></a>
    <div class="nav__menu" id="nav-menu">
      <ul class="nav__list">
        <li class="nav__item"><a href="index.php" class="nav__link">Home</a></li>
        <li class="nav__item"><a href="events.php" class="nav__link">Eventos</a></li>
        <li class="nav__item"><a href="logout.php" class="nav__link">Logout</a></li>
      </ul>
      <div class="nav__close" id="nav-close"><i class="ri-close-line"></i></div>
    </div>
    <div class="nav__toggle" id="nav-toggle"><i class="ri-menu-line"></i></div>
  </nav>
</header>

<main class="main container">
  <h1>Painel Principal</h1>
  <ul>
    <li>Total Users: <?= $totalUsers ?></li>
    <li>Total Eventos: <?= $totalEvents ?></li>
    <li>Total Compras: <?= $totalPurchases ?></li>
  </ul>

  <!-- EVENTOS -->
  <h2>Eventos</h2>
  <button class="btn btn-success mb-3" onclick="openCreateEventModal()">Criar Novo Evento</button>
  <table class="table table-striped table-hover">
    <thead>
      <tr>
        <th>Título</th>
        <th>Data</th>
        <th>Local</th>
        <th>Preço</th>
        <th>Ações</th>
      </tr>
    </thead>
    <tbody>
      <?php foreach ($events as $e): ?>
      <tr>
        <td><?= htmlspecialchars($e['title']); ?></td>
        <td><?= date('d/m/Y', strtotime($e['event_date'])); ?></td>
        <td><?= htmlspecialchars($e['location']); ?></td>
        <td>€<?= number_format($e['ticket_price'], 2, ',', '.'); ?></td>
        <td>
          <button class="btn btn-sm btn-outline-primary"
            onclick="openEditEventModal(
              <?= $e['id']; ?>,
              '<?= addslashes($e['title']); ?>',
              '<?= addslashes($e['description']); ?>',
              '<?= $e['event_date']; ?>',
              '<?= $e['event_time']; ?>',
              '<?= addslashes($e['location']); ?>',
              <?= $e['ticket_price']; ?>,
              <?= $e['available_tickets']; ?>,
              '<?= addslashes($e['image_url'] ?? ''); ?>'
            )"><i class="ri-edit-line"></i></button>
          <button class="btn btn-sm btn-outline-danger" onclick="openDeleteEventModal(<?= $e['id']; ?>)">
            <i class="ri-delete-bin-line"></i>
          </button>
        </td>
      </tr>
      <?php endforeach; ?>
    </tbody>
  </table>

  <!-- USERS -->
  <h2>Utilizadores</h2>
  <table class="table table-striped table-hover">
    <thead><tr><th>Username</th><th>Email</th><th>Posição</th><th>Ações</th></tr></thead>
    <tbody>
      <?php foreach ($users as $u): ?>
      <tr>
        <td><?= htmlspecialchars($u['username']); ?></td>
        <td><?= htmlspecialchars($u['email']); ?></td>
        <td><?= $u['role']; ?></td>
        <td>
          <button class="btn btn-sm btn-outline-primary"
            onclick="openEditModal(<?= $u['id']; ?>,'<?= addslashes($u['username']); ?>','<?= addslashes($u['email']); ?>','<?= $u['role']; ?>')">
            <i class="ri-edit-line"></i>
          </button>
          <button class="btn btn-sm btn-outline-danger" onclick="openDeleteModal(<?= $u['id']; ?>)">
            <i class="ri-delete-bin-line"></i>
          </button>
        </td>
      </tr>
      <?php endforeach; ?>
    </tbody>
  </table>

  <!-- COMPRAS -->
  <h2>Compras</h2>
  <table class="table table-striped table-hover">
    <thead>
      <tr>
        <th>User</th>
        <th>Evento</th>
        <th>Qte</th>
        <th>Total</th>
        <th>Status</th>
        <th>Data</th>
        <th>Ações</th>
      </tr>
    </thead>
    <tbody>
      <?php foreach ($purchases as $p): ?>
      <tr data-purchase-id="<?= $p['id']; ?>">
        <td><?= htmlspecialchars($p['username']); ?></td>
        <td><?= htmlspecialchars($p['title']); ?></td>
        <td class="purchase-quantity"><?= $p['quantity']; ?></td>
        <td>€<?= number_format($p['total_price'], 2, ',', '.'); ?></td>
        <td class="purchase-status"><?= ucfirst($p['status']); ?></td>
        <td><?= date('d/m/Y H:i', strtotime($p['purchase_date'])); ?></td>
        <td>
          <button class="btn btn-sm btn-outline-primary"
            onclick="openEditPurchaseModal(<?= $p['id']; ?>, <?= $p['user_id']; ?>, <?= $p['event_id']; ?>, <?= $p['quantity']; ?>, '<?= $p['status']; ?>')">
            <i class="ri-edit-line"></i>
          </button>
          <button class="btn btn-sm btn-outline-danger" onclick="openDeletePurchaseModal(<?= $p['id']; ?>)">
            <i class="ri-delete-bin-line"></i>
          </button>
        </td>
      </tr>
      <?php endforeach; ?>
    </tbody>
  </table>
</main>

<!-- Modulos -->
<?php include "admin_modals.php"; ?>

<footer class="footer">
  <div class="container">
    <p>&copy; 2025 EventHive</p>
  </div>
</footer>


<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.7/dist/js/bootstrap.bundle.min.js"></script>
<script src="./Script/script.js"></script>
</body>
</html>
