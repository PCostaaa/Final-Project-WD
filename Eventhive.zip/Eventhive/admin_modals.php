<!-- Módulos dos Eventos -->
<div class="modal fade" id="eventModal" tabindex="-1">
  <div class="modal-dialog modal-dialog-centered">
    <form class="modal-content" id="eventForm" method="post" enctype="multipart/form-data">
      <div class="modal-header">
        <h5 class="modal-title" id="eventModalTitle">Criar Evento</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>
      <div class="modal-body">
        <input type="hidden" name="id" id="eventId">
        <label for="eventTitle" class="form-label">Título</label>
        <input type="text" name="title" id="eventTitle" class="form-control" required>
        <label for="eventDescription" class="form-label mt-2">Descrição</label>
        <textarea name="description" id="eventDescription" class="form-control" required></textarea>
        <label class="form-label mt-2">Imagem</label>
        <input type="file" name="event_image" id="eventImage" class="form-control" accept="image/*">
        <img id="imagePreview" src="#" class="img-fluid mt-2 rounded d-none">
        <label class="form-label mt-2">Data</label>
        <input type="date" name="event_date" id="eventDate" class="form-control" required>
        <label class="form-label mt-2">Hora</label>
        <input type="time" name="event_time" id="eventTime" class="form-control" required>
        <label class="form-label mt-2">Local</label>
        <input type="text" name="location" id="eventLocation" class="form-control" required>
        <label class="form-label mt-2">Preço</label>
        <input type="number" step="0.01" name="ticket_price" id="eventPrice" class="form-control" required>
        <label class="form-label mt-2">Bilhetes</label>
        <input type="number" name="available_tickets" id="eventTickets" class="form-control" required>
      </div>
      <div class="modal-footer">
        <button type="submit" class="btn btn-primary" id="saveEventButton">Guardar</button>
      </div>
    </form>
  </div>
</div>

<!-- Módulo para editar USER -->
<div class="modal fade" id="editUserModal" tabindex="-1">
  <div class="modal-dialog modal-dialog-centered">
    <form class="modal-content" id="editUserForm">
      <div class="modal-header"><h5 class="modal-title">Editar Utilizador</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button></div>
      <div class="modal-body">
        <input type="hidden" name="id" id="editUserId">
        <label class="form-label">Username</label>
        <input type="text" name="username" id="editUsername" class="form-control" required>
        <label class="form-label mt-2">Email</label>
        <input type="email" name="email" id="editEmail" class="form-control" required>
        <label class="form-label mt-2">Posição</label>
        <select name="role" id="editRole" class="form-select">
          <option value="user">User</option>
          <option value="admin">Admin</option>
        </select>
      </div>
      <div class="modal-footer"><button type="submit" class="btn btn-primary">Guardar</button></div>
    </form>
  </div>
</div>

<!-- Módulo para apagar USER -->
<div class="modal fade" id="deleteUserModal" tabindex="-1">
  <div class="modal-dialog modal-dialog-centered">
    <form class="modal-content" id="deleteUserForm">
      <div class="modal-header"><h5 class="modal-title">Apagar Utilizador</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button></div>
      <div class="modal-body"><input type="hidden" name="id" id="deleteUserId">
        <p>Tem a certeza?</p></div>
      <div class="modal-footer"><button type="submit" class="btn btn-danger">Eliminar</button></div>
    </form>
  </div>
</div>

<!-- Módulo para editar compras -->
<div class="modal fade" id="editPurchaseModal" tabindex="-1">
  <div class="modal-dialog modal-dialog-centered">
    <form class="modal-content" id="editPurchaseForm">
      <div class="modal-header"><h5 class="modal-title">Editar Compra</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button></div>
      <div class="modal-body">
        <input type="hidden" name="purchase_id" id="editPurchaseId">
        <label class="form-label">ID Utilizador</label>
        <input type="number" name="user_id" id="editPurchaseUser" class="form-control" required>
        <label class="form-label mt-2">ID Evento</label>
        <input type="number" name="event_id" id="editPurchaseEvent" class="form-control" required>
        <label class="form-label mt-2">Quantidade</label>
        <input type="number" name="quantity" id="editPurchaseQuantity" class="form-control" required>
        <label class="form-label mt-2">Status</label>
        <select name="status" id="editPurchaseStatus" class="form-select" required>
          <option value="pending">Pendente</option>
          <option value="completed">Completado</option>
          <option value="cancelled">Cancelado</option>
        </select>
      </div>
      <div class="modal-footer"><button type="submit" class="btn btn-primary">Guardar</button></div>
    </form>
  </div>
</div>

<!-- Delete Purchase Modal -->
<div class="modal fade" id="deletePurchaseModal" tabindex="-1">
  <div class="modal-dialog modal-dialog-centered">
    <form class="modal-content" id="deletePurchaseForm">
      <div class="modal-header"><h5 class="modal-title">Apagar Compra</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button></div>
      <div class="modal-body"><input type="hidden" name="purchase_id" id="deletePurchaseId"><p>Tem a certeza?</p></div>
      <div class="modal-footer"><button type="submit" class="btn btn-danger">Eliminar</button></div>
    </form>
  </div>
</div>
