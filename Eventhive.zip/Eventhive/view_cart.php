<?php
session_start();
require_once __DIR__ . '/dbconnection.php';

$cart = $_SESSION['cart'] ?? [];        // formato: [event_id => quantity]
$totalPrice = 0.0;
$eventsById = [];
$adjusted = false;

if (!empty($cart)) {
    $ids = array_keys($cart);
    $ids = array_values(array_filter($ids, fn($v) => ctype_digit((string)$v)));
    if (!empty($ids)) {
        $placeholders = implode(',', array_fill(0, count($ids), '?'));
        $stmt = $pdo->prepare("SELECT id, title, ticket_price, available_tickets FROM events WHERE id IN ($placeholders)");
        $stmt->execute($ids);
        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            $eventsById[(int)$row['id']] = $row;
        }
    }

    // Ajustar carrinho ao stock atual
    foreach ($cart as $eventId => $qty) {
        $eventId = (int)$eventId;
        $qty = (int)$qty;
        $ev = $eventsById[$eventId] ?? null;
        if (!$ev) { // evento removido → retirar do carrinho
            unset($cart[$eventId]);
            $adjusted = true;
            continue;
        }
        $stock = (int)$ev['available_tickets'];
        if ($stock <= 0) {
            unset($cart[$eventId]); // esgotado → retirar
            $adjusted = true;
            continue;
        }
        if ($qty > $stock) {
            $cart[$eventId] = $stock; // reduzir à disponibilidade
            $adjusted = true;
        }
    }
    if ($adjusted) {
        $_SESSION['cart'] = $cart; // persistir ajustes
    }
}
?>
<!DOCTYPE html>
<html lang="pt-PT">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="description" content="Carrinho de compras da EventHive">
  <meta name="keywords" content="Gestão de eventos, bilhetes, concertos, espetáculos, festivais, artistas, bandas, música, cultura">
  <meta name="author" content="Pedro Costa">
  <title>Carrinho de Compras - EventHive</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.7/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/remixicon/4.6.0/remixicon.css">
  <link rel="stylesheet" href="./Styles/style.css">
</head>
<body>
<header class="header">
  <nav class="nav container">
    <a href="index.php" class="nav__logo"><img src="./Images/logo.png" alt="logo EventHive"></a>
  </nav>
</header>

<main class="main container">
  <h1 class="my-4">O seu Carrinho de Compras</h1>

  <?php if (!empty($cart)): ?>
    <div class="table-responsive">
      <table class="table table-striped">
        <thead>
          <tr>
            <th class="text-end">Evento</th>
            <th class="text-end">Preço Unitário</th>
            <th class="text-end">Quantidade</th>
            <th class="text-end">Subtotal</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($cart as $eventId => $quantity): ?>
            <?php
            $eventId = (int)$eventId;
            $quantity = (int)$quantity;
            $event = $eventsById[$eventId] ?? null;

            $title = $event ? $event['title'] : 'Evento indisponível';
            $price = $event ? (float)$event['ticket_price'] : 0.0;
            $subtotal = $price * $quantity;
            $totalPrice += $subtotal;
            ?>
            <tr>
              <td><?= htmlspecialchars($title) ?></td>
              <td>€ <?= number_format($price, 2, ',', '.') ?></td>
              <td><?= $quantity ?></td>
              <td>€ <?= number_format($subtotal, 2, ',', '.') ?></td>
            </tr>
          <?php endforeach; ?>
          <td class="text-end">
            <form action="remove_from_cart.php" method="post" class="d-inline">
                <input type="hidden" name="id" value="<?= (int)$eventId ?>">
                <input type="hidden" name="return" value="view_cart.php">
                <button type="submit" class="btn btn-utline-danger btn-sm" onclick="return confirm('Remover este item?');">
                    Remover
                </button>
            </form>
          </td>
        </tbody>
        <tfoot>
          <tr>
            <td colspan="3" class="text-end"><strong>Total:</strong></td>
            <td><strong>€ <?= number_format($totalPrice, 2, ',', '.') ?></strong></td>
          </tr>
        </tfoot>
      </table>
    </div>

    <div class="text-end mt-4">
      <a href="events.php" class="btn btn-secondary">Continuar a Comprar</a>
      <form id="checkoutForm" action="checkout_process.php" method="post" class="d-inline">
        <button type="submit" id="finalizeBtn" class="btn btn-primary">Finalizar Compra</button>
      </form>
    </div>

  <?php else: ?>
    <div class="alert alert-info text-center">
      <i class="ri-shopping-cart-line me-2"></i>O seu carrinho está vazio.
    </div>
    <div class="text-center">
      <a href="events.php" class="btn btn-primary">Voltar para Eventos</a>
    </div>
  <?php endif; ?>
</main>

<footer class="footer">
  <div class="container">
    <p>&copy; 2025 EventHive. Todos os direitos reservados.</p>
  </div>
</footer>

<script>
  document.getElementById('finalizeBtn')?.addEventListener('click', function () {
    document.getElementById('checkoutForm')?.submit();
  });
</script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.7/dist/js/bootstrap.bundle.min.js"></script>
<script src="./Script/script.js"></script>
</body>
</html>
