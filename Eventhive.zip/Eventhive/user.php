<?php
session_start();

if (!isset($_SESSION['username']) || $_SESSION['role'] !== 'user') {
    header("Location: index.php");
    exit();
}

require_once "dbconnection.php";

// Encontra o utilizador através do username
$username = $_SESSION['username'];

$stmt = $pdo->prepare("SELECT id, username, email FROM users WHERE username = ?");
$stmt->execute([$username]);
$user = $stmt->fetch();

if (!$user) {
    // Se o utilizador não é encontrado, é efetuado o logout
    header("Location: logout.php");
    exit();
}

$user_id = $user['id'];

// Trata de atualizar o perfil
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST['update_profile'])) {
    $new_username = trim($_POST['username']);
    $new_email = trim($_POST['email']);

    $updateStmt = $pdo->prepare("UPDATE users SET username = ?, email = ? WHERE id = ?");
    $updateStmt->execute([$new_username, $new_email, $user_id]);

    // Atualiza o nome da sessão
    $_SESSION['username'] = $new_username;

    header("Location: user.php");
    exit();
}

// Procura o histórico de compras
$pstmt = $pdo->prepare("
    SELECT p.id, e.title, e.event_date, e.event_time, p.quantity, p.total_price, p.status, p.purchase_date
    FROM purchases p
    JOIN events e ON p.event_id = e.id
    WHERE p.user_id = ?
    ORDER BY p.purchase_date DESC
");
$pstmt->execute([$user_id]);
$purchase_results = $pstmt->fetchAll();
?>


<!DOCTYPE html>
<html lang="pt-PT">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="description" content="Painel de administração da EventHive">
  <meta name="keywords" content="Gestão de eventos, bilhetes, concertos, espetáculos, festivais, artistas, bandas, música, cultura">
  <meta name="author" content="Pedro Costa">
  <title>Painel Principal do Utilizador</title>
  
  <link rel="stylesheet" href="./Styles/style.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/remixicon/4.6.0/remixicon.css" xintegrity="sha512-kJlvECunwXftkPwyvHbclArO8wszgBGisiLeuDFwNM8ws+wKIw0sv1os3ClWZOcrEB2eRXULYUsm8OVRGJKwGA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.7/dist/css/bootstrap.min.css" rel="stylesheet" xintegrity="sha384-LN+7fdVzj6u52u30Kp6M/trliBMCMKTyK833zpbD+pXdCLuTusPj697FH4R/5mcr" crossorigin="anonymous">
</head>
<body>
  <header>
    <nav class="nav container">
      <a href="index.php" class="nav__logo" style="text-decoration: none; color: black;">Home</a>
      <div class="nav__actions">
        <span>Bem-vindo, <strong><?php echo htmlspecialchars($_SESSION['username']); ?></strong></span>
        <a href="logout.php" style="text-decoration: none; color: black;">Logout</a>
      </div>
    </nav>
  </header>

  <main class="main container dashboard">
    <section class="profile-section">
    <h2 class="profile-title"><i class="ri-user-line"></i>O Meu Perfil</h2>
    <form method="POST" class="profile-form">
        <div class="form-group">
            <label for="username">Nome de Utilizador:</label>
            <input type="text" id="username" name="username" value="<?php echo htmlspecialchars($user['username']); ?>" required>
        </div>

        <div class="form-group">
            <label for="email">Email:</label>
            <input type="email" id="email" name="email" value="<?php echo htmlspecialchars($user['email']); ?>" required>
        </div>

        <button type="submit" name="update_profile" class="profile-button">
        <i class="ri-save-line"></i> Atualizar
        </button>
    </form>

    <p class="profile-note">As alterações serão guardadas automaticamente após confirmação.</p>
    </section>

  <h2>Histórico de Compras</h2>
  <div class="table-controls">
    <input type="text" id="tableFilter" placeholder="Filtrar por evento ou estado...">

  <div class="date-range">
    <label>De: <input type="date" id="startDate"></label>
    <label>Até: <input type="date" id="endDate"></label>
  </div>
  
  <div class="sort-options">
    <label>Ordenar por:
      <select id="sortSelector">
        <option value="none">-- Selecionar --</option>
        <option value="date_event">Data do Evento</option>
        <option value="date_purchase">Data de compra</option>
        <option value="price">Preço</option>
        <option value="quantity">Quantidade</option>
      </select>
    </label>
  </div>
  </div>

    <table class="purchase-history">
      <thead>
        <tr>
          <th>Evento</th>
          <th>Data</th>
          <th>Hora</th>
          <th>Qtde</th>
          <th>Total</th>
          <th>Status</th>
          <th>Data de compra</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($purchase_results as $row): ?>
        <tr>
          <td><?php echo htmlspecialchars($row['title']); ?></td>
          <td><?php echo htmlspecialchars($row['event_date']); ?></td>
          <td><?php echo htmlspecialchars($row['event_time']); ?></td>
          <td><?php echo $row['quantity']; ?></td>
          <td>€<?php echo $row['total_price']; ?></td>
          <td><?php echo ucfirst($row['status']); ?></td>
          <td><?php echo $row['purchase_date']; ?></td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</main>

  <!-- FOOTER -->
  <footer class="footer">
    <div class="container">
      <p>&copy; 2025 EventHive. Todos os direitos reservados.</p>
    </div>
  </footer>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.7/dist/js/bootstrap.bundle.min.js" integrity="sha384-ndDqU0Gzau9qJ1lfW4pNLlhNTkCfHzAVBReH9diLvGRem5+R9g2FzA8ZGN954O5Q" crossorigin="anonymous"></script>
<script src="./Script/script.js"></script>
</body>
</html>
